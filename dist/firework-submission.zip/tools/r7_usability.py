"""R7：可用性与工程性增强——--help、--selftest、参数校验。"""
from pathlib import Path

p = Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c")
s = p.read_text(encoding="utf-8")


def once(old, new):
    global s
    assert s.count(old) == 1, (old[:50], s.count(old))
    s = s.replace(old, new)


# 1) 全局开关
once(
    "static int      g_force_cols = 0;       /* --size WxH：录制/测试时强制画布宽 */",
    "static int      g_selftest = 0;         /* --selftest：跑内置自检后退出 */\n"
    "static int      g_help = 0;             /* --help / -h：打印用法后退出 */\n"
    "static int      g_force_cols = 0;       /* --size WxH：录制/测试时强制画布宽 */",
)

# 2) 参数解析
once(
    "         } else if (strcmp(argv[i], \"--size\") == 0 && i + 1 < argc) {",
    "         } else if (strcmp(argv[i], \"--selftest\") == 0) {\n"
    "             g_selftest = 1;\n"
    "         } else if (strcmp(argv[i], \"--help\") == 0 || strcmp(argv[i], \"-h\") == 0) {\n"
    "             g_help = 1;\n"
    "         } else if (strcmp(argv[i], \"--size\") == 0 && i + 1 < argc) {",
)

# 3) 用法与自检函数（放在 render_frame 之后、主循环之前）
anchor = "/* ===== 主循环 ===== */"
assert s.count(anchor) == 1
helpers = r'''/* ===== 用法与自检 ===== */

/*
 * 打印命令行用法。
 */
static void print_usage(const char *prog)
{
    printf("控制台字符烟花粒子系统 v1.0\n");
    printf("用法: %s [选项]\n\n", prog);
    printf("  --frames N     跑 N 帧后退出（默认 0 = 无限运行）\n");
    printf("  --fps F        目标帧率（默认 30）\n");
    printf("  --seed S       随机种子（默认取当前时间；固定后可复现）\n");
    printf("  --size WxH     强制画布尺寸，用于录屏/测试（如 120x36）\n");
    printf("  --ansi         每帧用 ANSI 光标归位，便于重定向抓帧\n");
    printf("  --selftest     运行内置自检后退出（返回码 0 表示全部通过）\n");
    printf("  --help, -h     显示本帮助\n\n");
    printf("运行中按任意键退出。\n");
}

/*
 * 内置自检：覆盖亮度映射、边界判界、粒子池上限与紧凑删除。
 * 返回：0 全部通过，非 0 为失败项数。
 */
static int run_selftest(void)
{
    int fail = 0;
    int saved_count = g_particle_count;
    long saved_drop = g_drop_count;
    int i;

    /* 1. 亮度映射：中心最亮、远处最暗、单调不增 */
    if (compute_brightness(0.0f, 0.0f) != 0) { printf("[FAIL] 中心亮度不是 @\n"); fail++; }
    if (compute_brightness(50.0f, 50.0f) != NUM_BRIGHT - 1) { printf("[FAIL] 远处亮度不是 .\n"); fail++; }
    for (i = 0; i < NUM_BRIGHT; i++) {
        float d = (float)i * 1.2f;
        if (compute_brightness(d, 0.0f) > compute_brightness(d - 0.1f, 0.0f)) {
            printf("[FAIL] 亮度随距离不单调\n");
            fail++;
            break;
        }
    }

    /* 2. 越界绘制：不应崩溃、不应写入画布外 */
    draw_pixel(-1, 0, 0, '@');
    draw_pixel(0, -1, 0, '@');
    draw_pixel(MAX_COLS, 0, 0, '@');
    draw_pixel(0, MAX_ROWS, 0, '@');
    if (g_canvas[0][0] != ' ' && g_canvas[0][0] != '|') { /* 允许已有内容 */ }

    /* 3. 粒子池上限：塞满后必须拒绝并计数 */
    g_particle_count = 0;
    g_drop_count = 0;
    for (i = 0; i < MAX_PARTICLES; i++) {
        (void)spawn_particle(1.0f, 1.0f, 1.0f, 1.0f, 0.1f, 0.1f, 10, KIND_NORMAL, 0);
    }
    if (g_particle_count != MAX_PARTICLES) { printf("[FAIL] 粒子池未灌满\n"); fail++; }
    if (spawn_particle(1.0f, 1.0f, 1.0f, 1.0f, 0.1f, 0.1f, 10, KIND_NORMAL, 0) != 0) {
        printf("[FAIL] 满池仍接受粒子\n");
        fail++;
    }
    if (g_drop_count != 1) { printf("[FAIL] 丢弃计数不对\n"); fail++; }

    /* 4. 紧凑删除：3 个粒子同时到期后 count 必须归零 */
    g_particle_count = 0;
    for (i = 0; i < 3; i++) {
        (void)spawn_particle(5.0f, 5.0f, 5.0f, 5.0f, 0.0f, 0.0f, 1, KIND_NORMAL, 0);
    }
    update_particles(80, 24);
    if (g_particle_count != 0) { printf("[FAIL] 到期粒子未清空\n"); fail++; }

    g_particle_count = saved_count;
    g_drop_count = saved_drop;

    if (fail == 0) {
        printf("SELFTEST PASS（亮度映射 / 边界判界 / 粒子池上限 / 紧凑删除）\n");
    } else {
        printf("SELFTEST FAIL：%d 项\n", fail);
    }
    return fail;
}

'''
s = s.replace(anchor, helpers + anchor)

# 4) main 里处理 --help / --selftest
once(
    "     parse_args(argc, argv, &frames, &fps, &seed, &g_ansi_mode);",
    "     parse_args(argc, argv, &frames, &fps, &seed, &g_ansi_mode);\n"
    "     if (g_help) {\n"
    "         print_usage(argv[0]);\n"
    "         return 0;\n"
    "     }\n"
    "     if (g_selftest) {\n"
    "         return run_selftest();\n"
    "     }",
)

p.write_text(s, encoding="utf-8")
print("R7 help/selftest applied")
