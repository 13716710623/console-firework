"""R3c 观感调优第二轮：垂直压缩（模拟终端字符长宽比）+ 更长的余烬 + 更密的并发。"""
import re
from pathlib import Path

p = Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c")
src = p.read_text(encoding="utf-8")


def sub_once(pattern, repl, flags=0):
    global src
    hits = re.findall(pattern, src, flags)
    if len(hits) != 1:
        raise SystemExit(f"pattern hits={len(hits)} for {pattern!r}")
    src = re.sub(pattern, lambda m: repl, src, count=1, flags=flags)


sub_once(r"#define MIN_LIFE        55 ", "#define MIN_LIFE        60 ")
sub_once(r"#define MAX_LIFE        95 ", "#define MAX_LIFE        105")
sub_once(r"#define PSPEED_MIN      0\.22f", "#define PSPEED_MIN      0.18f")
sub_once(r"#define PSPEED_MAX      0\.90f", "#define PSPEED_MAX      0.60f")
sub_once(r"#define LAUNCH_INTERVAL_MIN 6  ", "#define LAUNCH_INTERVAL_MIN 4  ")
sub_once(r"#define LAUNCH_INTERVAL_MAX 18 ", "#define LAUNCH_INTERVAL_MAX 12 ")
sub_once(r"#define GRAVITY         0\.032f", "#define GRAVITY         0.030f")

# 垂直速度压缩到 0.55：终端字符高约为宽的两倍，压缩后爆炸才接近圆形
sub_once(
    r"            p->vx = UNIT_X\[k\] \* speed;\n            p->vy = UNIT_Y\[k\] \* speed;",
    "            p->vx = UNIT_X[k] * speed;\n"
    "            /* 终端字符高约为宽的两倍，纵向速度压到 0.55 倍，爆炸轮廓才接近圆形 */\n"
    "            p->vy = UNIT_Y[k] * speed * 0.55f;",
)

p.write_text(src, encoding="utf-8")
print("R3c tuning applied")
