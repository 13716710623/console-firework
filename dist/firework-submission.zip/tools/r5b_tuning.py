"""R5b：柳条/环形/牡丹三类爆裂的可辨识度调参。"""
from pathlib import Path

p = Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c")
s = p.read_text(encoding="utf-8")

reps = [
    # 柳条：更慢、更少重力、寿命适中，才能在屏幕内形成垂落光丝
    ("#define WILLOW_GRAVITY_SCALE   1.45f", "#define WILLOW_GRAVITY_SCALE   1.10f"),
    ("        max_speed = PSPEED_MAX * 0.72f; vy_scale = 0.75f;\n        life_min = 140; life_max = 210;",
     "        max_speed = PSPEED_MAX * 0.42f; vy_scale = 0.55f;\n        life_min = 120; life_max = 180;"),
    # 环形：2~3 层 + 轻微速度抖动，减轻字符网格造成的“方框感”
    ("        dirs = RAY_DIRS; layers = 1 + rand() % 2;",
     "        dirs = RAY_DIRS; layers = 2 + rand() % 2;"),
    # 牡丹：层数上限提高，体量更足
    ("#define RAY_LAYERS_MIN  3", "#define RAY_LAYERS_MIN  4"),
    ("#define RAY_LAYERS_MAX  6", "#define RAY_LAYERS_MAX  8"),
]
for old, new in reps:
    assert s.count(old) == 1, (old, s.count(old))
    s = s.replace(old, new)

# 环形速度抖动：在 speed = max_speed * f 之后加一点随机
old = "            speed = max_speed * f;\n            life = life_min + rand() % (life_max - life_min + 1);"
new = ("            speed = max_speed * f;\n"
       "            if (type == EX_RING) {\n"
       "                speed *= 0.96f + (float)(rand() % 100) / 1250.0f;   /* 环形加抖动，减轻网格方框感 */\n"
       "            }\n"
       "            life = life_min + rand() % (life_max - life_min + 1);")
assert s.count(old) == 1
s = s.replace(old, new)

p.write_text(s, encoding="utf-8")
print("R5b tuning applied")
