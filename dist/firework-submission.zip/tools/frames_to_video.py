"""把 --ansi 抓帧结果渲染成 PNG 序列并用 ffmpeg 合成 MP4（真实的程序输出，非手绘）。

用法：
  python frames_to_video.py <raw.txt> <outdir> --ffmpeg <ffmpeg.exe> [--fps 30] [--scale 2]
"""
import argparse
import os
import re
import shutil
import subprocess
import sys

ANSI_HOME = re.compile(r"\x1b\[H|\x1b\[1;1H")
ANSI_ANY = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
CLEAR = re.compile(r"\x1b\[2J")

PALETTE = [
    (255, 255, 236),   # @
    (255, 232, 170),   # O
    (255, 205, 125),   # o
    (245, 170, 95),    # *
    (215, 130, 80),    # ,
    (180, 105, 80),    # .
]


def split_frames(raw: str):
    raw = raw.replace("\r\n", "\n").replace("\r", "\n")
    frames = []
    for part in ANSI_HOME.split(raw):
        clean = CLEAR.sub("", ANSI_ANY.sub("", part))
        lines = [ln.rstrip() for ln in clean.split("\n")]
        while lines and not lines[-1].strip():
            lines.pop()
        if lines:
            frames.append(lines)
    return frames


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw")
    ap.add_argument("outdir")
    ap.add_argument("--ffmpeg", required=True)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--scale", type=int, default=2, help="像素放大倍数")
    ap.add_argument("--keep-frames", action="store_true")
    args = ap.parse_args()

    from PIL import Image, ImageDraw, ImageFont

    raw = open(args.raw, encoding="utf-8", errors="replace").read()
    frames = split_frames(raw)
    if not frames:
        print("no frames")
        return 1
    rows = max(len(f) for f in frames)
    cols = max(max((len(l) for l in f), default=0) for f in frames)
    print(f"frames={len(frames)} rows={rows} cols={cols}")

    font = None
    for cand in (r"C:\Windows\Fonts\consola.ttf", r"C:\Windows\Fonts\cour.ttf"):
        if os.path.exists(cand):
            font = ImageFont.truetype(cand, 16)
            break
    if font is None:
        font = ImageFont.load_default()

    cw, ch = 10 * args.scale, 18 * args.scale
    margin = 10
    W = cols * cw + margin * 2
    H = rows * ch + margin * 2
    W -= W % 2
    H -= H % 2

    frame_dir = os.path.join(args.outdir, "_frames")
    if os.path.isdir(frame_dir):
        shutil.rmtree(frame_dir)
    os.makedirs(frame_dir, exist_ok=True)

    for idx, frame in enumerate(frames):
        img = Image.new("RGB", (W, H), (6, 8, 18))
        d = ImageDraw.Draw(img)
        for r, line in enumerate(frame):
            for c, ch_ in enumerate(line):
                if ch_ == " ":
                    continue
                level = "@Oo*,.".find(ch_)
                if level < 0:
                    level = 5
                d.text((margin + c * cw, margin + r * ch), ch_, font=font,
                       fill=PALETTE[level])
        img.save(os.path.join(frame_dir, f"f_{idx:04d}.png"))

    mp4 = os.path.join(args.outdir, "firework.mp4")
    cmd = [
        args.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-framerate", str(args.fps), "-i", os.path.join(frame_dir, "f_%04d.png"),
        "-c:v", "h264_mf", "-pix_fmt", "yuv420p", "-b:v", "6M", "-r", str(args.fps),
        mp4,
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(mp4) or os.path.getsize(mp4) < 10000:
        print("h264_mf failed:", r.stderr[-400:])
        cmd[cmd.index("h264_mf")] = "mpeg4"
        cmd[cmd.index("mpeg4") + 1:cmd.index("mpeg4") + 1] = ["-q:v", "4"]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            print("fallback failed:", r.stderr[-400:])
            return 1
    print("mp4 ->", mp4, os.path.getsize(mp4), "bytes")
    if not args.keep_frames:
        shutil.rmtree(frame_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
