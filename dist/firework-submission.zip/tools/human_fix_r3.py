"""R3 人工修复与调参：把 R2 评审发现的 5 处问题落到代码里。

每处替换都断言“恰好命中一次”，避免误改。
"""
import re
from pathlib import Path

p = Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c")
src = p.read_text(encoding="utf-8")


def sub_once(pattern, repl, flags=0):
    global src
    hits = re.findall(pattern, src, flags)
    if len(hits) != 1:
        raise SystemExit(f"pattern hits={len(hits)} for {pattern!r}")
    src = re.sub(pattern, lambda m: repl, src, count=1, flags=flags)


# 1) 参数调优：更密的烟花、更长的寿命、更慢的扩散、更短的发射间隔
sub_once(r"#define MIN_PARTICLES   80 ", "#define MIN_PARTICLES   110")
sub_once(r"#define MAX_EXPLOSION   200", "#define MAX_EXPLOSION   240")
sub_once(r"#define MIN_LIFE        40 ", "#define MIN_LIFE        55 ")
sub_once(r"#define MAX_LIFE        80 ", "#define MAX_LIFE        95 ")
sub_once(r"#define GRAVITY         0\.04f", "#define GRAVITY         0.032f")
sub_once(r"#define PSPEED_MIN      0\.3f ", "#define PSPEED_MIN      0.22f")
sub_once(r"#define PSPEED_MAX      1\.2f ", "#define PSPEED_MAX      0.85f")
sub_once(r"#define LAUNCH_INTERVAL_MIN 20 ", "#define LAUNCH_INTERVAL_MIN 10 ")
sub_once(r"#define LAUNCH_INTERVAL_MAX 60 ", "#define LAUNCH_INTERVAL_MAX 30 ")

# 1b) 亮度分层收窄，让爆心周围有明显的 @ O o * 层次
sub_once(r"#define BDIST0   4\.0f ", "#define BDIST0   2.25f")
sub_once(r"#define BDIST1   16\.0f", "#define BDIST1   9.0f ")
sub_once(r"#define BDIST2   36\.0f", "#define BDIST2   25.0f")
sub_once(r"#define BDIST3   81\.0f", "#define BDIST3   49.0f")
sub_once(r"#define BDIST4   144\.0f", "#define BDIST4   81.0f")

# 1c) 注释同步（阈值改了，行尾注释也要改）
for old, new in [
    ("d < 2.0  -> '@'", "d < 1.5  -> '@'"),
    ("d < 4.0  -> 'O'", "d < 3.0  -> 'O'"),
    ("d < 6.0  -> 'o'", "d < 5.0  -> 'o'"),
    ("d < 9.0  -> '*'", "d < 7.0  -> '*'"),
    ("d < 12.0 -> ','", "d < 9.0  -> ','"),
]:
    sub_once(re.escape(old), new)

# 2) 粒子增加 max_life，用于“余烬变暗”
sub_once(
    r"    int   life;       /\* 剩余寿命（帧） \*/",
    "    int   life;       /* 剩余寿命（帧） */\n    int   max_life;   /* 出生寿命（用于余烬变暗） */",
)
sub_once(
    r"        p->life = MIN_LIFE \+ rand\(\) % \(MAX_LIFE - MIN_LIFE \+ 1\);",
    "        p->life = MIN_LIFE + rand() % (MAX_LIFE - MIN_LIFE + 1);\n        p->max_life = p->life;",
)

# 3) 余烬变暗：寿命进入最后 1/3 时亮度降一档
sub_once(
    r"        b  = compute_brightness\(dx, dy\);\n        draw_pixel\(px, py, b, BRIGHT_CHARS\[b\]\);",
    "        b  = compute_brightness(dx, dy);\n"
    "        /* 余烬变暗：寿命进入最后 1/3 时亮度降一档，形成“燃烧殆尽”的观感 */\n"
    "        if (p->max_life > 0 && p->life * 3 < p->max_life && b < NUM_BRIGHT - 1) {\n"
    "            b++;\n"
    "        }\n"
    "        draw_pixel(px, py, b, BRIGHT_CHARS[b]);",
)

# 4) 画布整幅清空（原来只清 cols×rows，draw_pixel 却按 MAX_COLS/MAX_ROWS 判界，
#    边缘区域残留上一帧亮度，会画出“幽灵像素”）
sub_once(
    r"static void clear_canvas\(int cols, int rows\)\n\{\n    int y, x;\n    for \(y = 0; y < rows; y\+\+\) \{\n        for \(x = 0; x < cols; x\+\+\) \{",
    "static void clear_canvas(void)\n{\n    int y, x;\n    for (y = 0; y < MAX_ROWS; y++) {\n        for (x = 0; x < MAX_COLS; x++) {",
)
sub_once(r"        clear_canvas\(cols, rows\);", "        clear_canvas();")
sub_once(
    r" \* 清空画布：填充空格，亮度标记设为最高值\(空白\)。\n \* 参数：cols/rows - 画布有效尺寸。",
    " * 清空画布：整幅填充空格，亮度标记设为最高值(空白)。\n"
    " * 说明：按 MAX_COLS/MAX_ROWS 全量清空，避免 draw_pixel 判界范围大于可见区域时残留幽灵像素。",
)

# 5) 退出不再擦屏：保留最后一帧，光标移到画面下方
sub_once(
    r"     /\* 清理退出：恢复终端、显示光标、清屏 \*/\n     restore_terminal\(\);\n     show_cursor\(\);\n     clear_screen\(\);\n     return 0;",
    "     /* 清理退出：恢复终端与光标，保留最后一帧画面（不清屏，方便观察与截图） */\n"
    "     restore_terminal();\n"
    "     show_cursor();\n"
    "     fputs(\"\\n\", stdout);\n"
    "     fflush(stdout);\n"
    "     return 0;",
)

# 6) 爆炸点若已飞出顶部（y<1），夹到第 1 行，避免整团粒子出生即被边界销毁
src = src.replace(
    "     int n = MIN_PARTICLES + rand() % (MAX_EXPLOSION - MIN_PARTICLES + 1);\n     int i;",
    "     int n = MIN_PARTICLES + rand() % (MAX_EXPLOSION - MIN_PARTICLES + 1);\n"
    "     int i;\n"
    "     if (cy < 1.0f) cy = 1.0f;   /* 爆炸点上边界夹紧：避免粒子出生即越界 */",
    1,
)

# 7) 缩进规整：把“单前导空格 + 非空白”的代码行去掉那个多余空格（块注释续行保持不动）
lines = src.split("\n")
fixed = []
for ln in lines:
    stripped = ln.lstrip()
    if ln.startswith(" ") and not ln.startswith("  ") and stripped and not stripped.startswith("*"):
        fixed.append(ln[1:])
    else:
        fixed.append(ln)
src = "\n".join(fixed)

p.write_text(src, encoding="utf-8")
print("R3 human fixes applied ->", p)
