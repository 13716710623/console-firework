"""把若干帧拼成一张对比图，便于人工/视觉模型检查爆炸类型。"""
import re
import sys
from PIL import Image, ImageDraw, ImageFont

PALETTE = [
    (255, 255, 236),   # @
    (255, 232, 170),   # O
    (255, 205, 125),   # o
    (245, 170, 95),    # *
    (215, 130, 80),    # ,
    (180, 105, 80),    # .
]


ANSI_HOME = re.compile(r"\x1b\[H|\x1b\[1;1H")
ANSI_ANY = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
CLEAR = re.compile(r"\x1b\[2J")


def split_frames(raw):
    raw = raw.replace("\r\n", "\n").replace("\r", "\n")
    out = []
    for part in ANSI_HOME.split(raw):
        clean = CLEAR.sub("", ANSI_ANY.sub("", part))
        lines = [ln.rstrip() for ln in clean.split("\n")]
        while lines and not lines[-1].strip():
            lines.pop()
        if lines:
            out.append(lines)
    return out


def main(raw_path, out_path, idxs):
    raw = open(raw_path, encoding="utf-8", errors="replace").read()
    frames = split_frames(raw)
    idxs = [i for i in idxs if 0 <= i < len(frames)]
    rows = max(len(frames[i]) for i in idxs)
    cols = max(max(len(l) for l in frames[i]) for i in idxs)

    font = ImageFont.truetype(r"C:\Windows\Fonts\consola.ttf", 14)
    cw, ch, pad = 9, 16, 10
    tile_w, tile_h = cols * cw + pad * 2, rows * ch + pad * 2 + 18
    grid_cols = 2
    grid_rows = (len(idxs) + grid_cols - 1) // grid_cols
    img = Image.new("RGB", (tile_w * grid_cols, tile_h * grid_rows), (4, 6, 14))
    d = ImageDraw.Draw(img)

    for n, i in enumerate(idxs):
        ox = (n % grid_cols) * tile_w
        oy = (n // grid_cols) * tile_h
        d.text((ox + pad, oy + 4), f"frame {i}", font=font, fill=(120, 200, 255))
        for r, line in enumerate(frames[i]):
            for c, ch_ in enumerate(line):
                if ch_ == " ":
                    continue
                level = "@Oo*,.".find(ch_)
                if level < 0:
                    level = 5
                d.text((ox + pad + c * cw, oy + 20 + r * ch), ch_, font=font,
                       fill=PALETTE[level])
    img.save(out_path)
    print("montage ->", out_path, img.size)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], [int(x) for x in sys.argv[3:]])
