"""R5：三种爆炸类型 + 二次爆裂 + 闪烁 + 重力曲线（选手手工实现，GLM 配额耗尽）。

按“函数块整体替换 + 断言锚点唯一”的方式改，避免误伤其它代码。
"""
from pathlib import Path

p = Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c")
s = p.read_text(encoding="utf-8")


def cut(start_marker: str, end_marker: str, new: str) -> None:
    global s
    a = s.find(start_marker)
    b = s.find(end_marker)
    if a < 0 or b < 0 or b <= a:
        raise SystemExit(f"anchor not found: {start_marker!r} / {end_marker!r}")
    if s.count(start_marker) != 1:
        raise SystemExit(f"anchor not unique: {start_marker!r}")
    s = s[:a] + new + s[b:]


# 1) 粒子结构体：加 kind / dim
old_struct = """typedef struct {
    float x, y;       /* 当前坐标（列, 行） */
    float vx, vy;     /* 速度 */
    int   life;       /* 剩余寿命（帧） */
    int   max_life;   /* 出生寿命（用于余烬变暗） */
    float cx, cy;     /* 爆炸中心坐标（用于亮度计算） */
} Particle;"""
new_struct = """typedef struct {
    float x, y;         /* 当前坐标（列, 行） */
    float vx, vy;       /* 速度 */
    int   life;         /* 剩余寿命（帧） */
    int   max_life;     /* 出生寿命（用于余烬变暗） */
    float cx, cy;       /* 爆炸中心坐标（用于亮度计算） */
    unsigned char kind; /* 粒子类型：普通 / 火星（消亡时二次爆裂）/ 闪烁 */
    unsigned char dim;  /* 整体压暗档数（柳条用） */
} Particle;"""
assert s.count(old_struct) == 1
s = s.replace(old_struct, new_struct)

# 2) 常量：爆炸类型、粒子类型、柳条参数
anchor = "#define RAY_DIRS        64            /* R4: 64 uniform directions per explosion */"
assert s.count(anchor) == 1
s = s.replace(anchor, anchor + """
/* R5：爆炸类型与粒子类型 */
enum { EX_PEONY = 0, EX_WILLOW = 1, EX_RING = 2 };
enum { KIND_NORMAL = 0, KIND_SPARK = 1, KIND_TWINKLE = 2 };
#define WILLOW_DIRS            32     /* 柳条：方向更少，垂感更强 */
#define WILLOW_GRAVITY_SCALE   1.45f  /* 柳条重力倍率：下坠更快 */
#define RING_SPEED_SCALE       1.05f  /* 环形：速度带更窄、更靠外 */
#define SPARK_MINI_COUNT       6      /* 火星二次爆裂的粒子数 */""")

# 3) explode 整块替换（含新的辅助函数）
new_explode = """/*
 * 随机选择本次爆炸的类型：牡丹 50%、柳条 30%、环形 20%。
 * 参数：无。
 * 返回：EX_PEONY / EX_WILLOW / EX_RING。
 */
static int choose_explosion_type(void)
{
    int r = rand() % 10;
    if (r < 5) return EX_PEONY;
    if (r < 8) return EX_WILLOW;
    return EX_RING;
}

/*
 * 追加一个粒子；粒子池满时丢弃并计数。
 * 参数：cx/cy - 爆心；x/y - 出生位置；vx/vy - 初速；life - 寿命；
 *       kind - 粒子类型；dim - 压暗档数。
 * 返回：1 成功，0 满池丢弃。
 */
static int spawn_particle(float cx, float cy, float x, float y,
                          float vx, float vy, int life,
                          unsigned char kind, unsigned char dim)
{
    Particle *q;
    if (g_particle_count >= MAX_PARTICLES) {
        g_drop_count++;
        return 0;
    }
    q = &g_particles[g_particle_count++];
    q->x = x;      q->y = y;
    q->vx = vx;    q->vy = vy;
    q->cx = cx;    q->cy = cy;
    q->life = life;
    q->max_life = life;
    q->kind = kind;
    q->dim = dim;
    return 1;
}

/*
 * 火星的二次爆裂：在粒子消亡处再炸出几颗小火星。
 * 参数：x/y - 消亡位置（调用方已保证在画布内）。
 */
static void mini_burst(float x, float y)
{
    int i;
    for (i = 0; i < SPARK_MINI_COUNT; i++) {
        int dir = rand() % UNIT_STEPS;
        float sp = 0.25f + (float)(rand() % 100) / 100.0f * 0.35f;
        spawn_particle(x, y, x, y,
                       UNIT_X[dir] * sp,
                       UNIT_Y[dir] * sp * 0.6f,
                       25 + rand() % 15, KIND_NORMAL, 1);
    }
}

/*
 * 爆炸：按类型生成粒子。
 * 参数：type - 爆炸类型；cx/cy - 爆心。
 * 边界：总粒子数受 MAX_PARTICLES 限制，满池丢弃并计数。
 */
static void explode(int type, float cx, float cy)
{
    int base_dir = rand() % RAY_DIRS;
    int dirs, layers, k, j;
    float max_speed, vy_scale;
    int life_min, life_max, dim, spark_pct, twinkle_pct;

    if (cy < 1.0f) cy = 1.0f;

    switch (type) {
    case EX_WILLOW:
        dirs = WILLOW_DIRS; layers = 4 + rand() % 5;
        max_speed = PSPEED_MAX * 0.72f; vy_scale = 0.75f;
        life_min = 140; life_max = 210;
        dim = 2; spark_pct = 0; twinkle_pct = 0;
        break;
    case EX_RING:
        dirs = RAY_DIRS; layers = 1 + rand() % 2;
        max_speed = PSPEED_MAX * RING_SPEED_SCALE; vy_scale = 0.55f;
        life_min = 60; life_max = 95;
        dim = 0; spark_pct = 0; twinkle_pct = 25;
        break;
    default:
        dirs = RAY_DIRS;
        layers = RAY_LAYERS_MIN + rand() % (RAY_LAYERS_MAX - RAY_LAYERS_MIN + 1);
        max_speed = PSPEED_MAX; vy_scale = 0.55f;
        life_min = MIN_LIFE; life_max = MAX_LIFE;
        dim = 0; spark_pct = 12; twinkle_pct = 12;
        break;
    }

    for (k = 0; k < dirs; k++) {
        int dir = (base_dir + k * RAY_DIRS / dirs) % RAY_DIRS;
        for (j = 0; j < layers; j++) {
            float speed, f;
            int life;
            unsigned char kind = KIND_NORMAL;

            if (type == EX_RING) {
                f = 0.90f + 0.10f * (float)j / (float)layers;   /* 只有外圈，形成空心环 */
            } else {
                f = 0.30f + 0.70f * (float)j / (float)layers;   /* 层数越大越靠外 */
            }
            speed = max_speed * f;
            life = life_min + rand() % (life_max - life_min + 1);

            if (spark_pct > 0 && (rand() % 100) < spark_pct) {
                kind = KIND_SPARK;
            } else if (twinkle_pct > 0 && (rand() % 100) < twinkle_pct) {
                kind = KIND_TWINKLE;
            }

            (void)0;
            if (!spawn_particle(cx, cy, cx, cy,
                                UNIT_X[dir] * speed,
                                UNIT_Y[dir] * speed * vy_scale,
                                life, kind, (unsigned char)dim)) {
                return;   /* 池满，整发提前结束 */
            }
        }
    }
}

"""
cut("/*\n * 爆炸：沿 64 个方向均匀发射", "/*\n * 更新火箭", new_explode)

# 4) update_particles：重力曲线 + 火星二次爆裂
new_update = """/*
 * 更新所有粒子：移动、重力曲线、递减寿命、火星二次爆裂、紧凑删除。
 * 参数：cols/rows - 画布尺寸。
 * 重力随存活时间增强：刚炸开时轻、临近熄灭时重，形成“先撑开再塌落”的节奏。
 */
static void update_particles(int cols, int rows)
{
    int i = 0;
    while (i < g_particle_count) {
        Particle *q = &g_particles[i];
        float age;
        q->x   += q->vx;
        q->y   += q->vy;
        age = 1.0f - (float)q->life / (float)(q->max_life > 0 ? q->max_life : 1);
        if (age < 0.0f) age = 0.0f;
        q->vy  += GRAVITY * (0.55f + 1.15f * age);
        if (q->dim >= 2) q->vy += GRAVITY * (WILLOW_GRAVITY_SCALE - 1.0f);
        q->life--;
        if (q->life <= 0 ||
            q->x < 0.0f || q->x >= (float)cols ||
            q->y < 0.0f || q->y >= (float)rows) {
            if (q->life <= 0 && q->kind == KIND_SPARK) {
                mini_burst(q->x, q->y);
            }
            g_particles[i] = g_particles[g_particle_count - 1];
            g_particle_count--;
        } else {
            i++;
        }
    }
}

"""
cut("static void update_particles(int cols, int rows)", "/* ===== 渲染 ===== */", new_update)

# 5) render_particles：压暗 + 闪烁
new_render = """/*
 * 渲染所有粒子到画布，按距爆炸中心距离映射亮度字符。
 * 参数：cols/rows - 画布尺寸（用于跳过越界粒子）。
 */
static void render_particles(int cols, int rows)
{
    int i;
    for (i = 0; i < g_particle_count; i++) {
        Particle *q = &g_particles[i];
        int px = (int)(q->x + 0.5f);
        int py = (int)(q->y + 0.5f);
        float dx, dy;
        int b;
        if (px < 0 || px >= cols || py < 0 || py >= rows) continue;
        dx = q->x - q->cx;
        dy = q->y - q->cy;
        b  = compute_brightness(dx, dy);
        /* 余烬变暗：寿命进入最后 1/3 时亮度降一档 */
        if (q->max_life > 0 && q->life * 3 < q->max_life && b < NUM_BRIGHT - 1) {
            b++;
        }
        b += q->dim;   /* 柳条整体更暗，像垂下的光丝 */
        /* 闪烁：按寿命与横坐标错相位，间歇压暗一格 */
        if (q->kind == KIND_TWINKLE &&
            ((q->life + (int)(q->x * 3.0f)) & 3) == 0 && b < NUM_BRIGHT - 1) {
            b++;
        }
        if (b > NUM_BRIGHT - 1) b = NUM_BRIGHT - 1;
        draw_pixel(px, py, b, BRIGHT_CHARS[b]);
    }
}

"""
cut("static void render_particles(int cols, int rows)", "/*\n * 构建帧缓冲", new_render)

# 6) 调用点：带类型爆炸
old_call = "        r->active = 0;\n        explode(r->x, r->y);"
assert s.count(old_call) == 1
s = s.replace(old_call, "        r->active = 0;\n        explode(choose_explosion_type(), r->x, r->y);")

p.write_text(s, encoding="utf-8")
print("R5 patch applied")
