"""R3b 视觉调优：径向均匀爆裂 + 火箭尾焰 + 更密的核心。

不引入 math.h（保持零额外链接依赖），方向向量用预计算表。
"""
import math
import re
from pathlib import Path

p = Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c")
src = p.read_text(encoding="utf-8")


def sub_once(pattern, repl, flags=0):
    global src
    hits = re.findall(pattern, src, flags)
    if len(hits) != 1:
        raise SystemExit(f"pattern hits={len(hits)} for {pattern!r}")
    src = re.sub(pattern, lambda m: repl, src, count=1, flags=flags)


STEPS = 64
rows = "\n".join(
    "    {:.4f}f, {:.4f}f, {:.4f}f, {:.4f}f, {:.4f}f, {:.4f}f, {:.4f}f, {:.4f}f,".format(
        *[math.cos(2 * math.pi * (i + j) / STEPS) for j in range(8)]
    )
    for i in range(0, STEPS, 8)
)
rows_y = "\n".join(
    "    {:.4f}f, {:.4f}f, {:.4f}f, {:.4f}f, {:.4f}f, {:.4f}f, {:.4f}f, {:.4f}f,".format(
        *[math.sin(2 * math.pi * (i + j) / STEPS) for j in range(8)]
    )
    for i in range(0, STEPS, 8)
)

table = f"""
/* 单位圆方向表：64 等分，避免引入 math.h / libm 依赖。
 * 索引 0..63 对应 0~2π，爆炸粒子按 i 均匀取方向，形成放射状而非随机散点。 */
#define UNIT_STEPS 64
static const float UNIT_X[UNIT_STEPS] = {{
{rows}
}};
static const float UNIT_Y[UNIT_STEPS] = {{
{rows_y}
}};
"""

# 1) 插入方向表（放在亮度字符表之后）
sub_once(
    r"static const char BRIGHT_CHARS\[NUM_BRIGHT\] = \{'@', 'O', 'o', '\*', ',', '\.'\};\n",
    "static const char BRIGHT_CHARS[NUM_BRIGHT] = {'@', 'O', 'o', '*', ',', '.'};\n" + table,
)

# 2) 参数：更多粒子、更短发射间隔
sub_once(r"#define MIN_PARTICLES   110", "#define MIN_PARTICLES   130")
sub_once(r"#define MAX_EXPLOSION   240", "#define MAX_EXPLOSION   260")
sub_once(r"#define LAUNCH_INTERVAL_MIN 10 ", "#define LAUNCH_INTERVAL_MIN 6  ")
sub_once(r"#define LAUNCH_INTERVAL_MAX 30 ", "#define LAUNCH_INTERVAL_MAX 18 ")
sub_once(r"#define PSPEED_MAX      0\.85f", "#define PSPEED_MAX      0.90f")

# 3) 爆炸：等角分布 + 速度偏向慢速（中心更亮更密）
sub_once(
    r"     int n = MIN_PARTICLES \+ rand\(\) % \(MAX_EXPLOSION - MIN_PARTICLES \+ 1\);\n     int i;\n     if \(cy < 1\.0f\) cy = 1\.0f;   /\* 爆炸点上边界夹紧：避免粒子出生即越界 \*/",
    "     int n = MIN_PARTICLES + rand() % (MAX_EXPLOSION - MIN_PARTICLES + 1);\n"
    "     int i;\n"
    "     int base = rand() % UNIT_STEPS;   /* 随机起始相位，避免每发烟花方向一致 */\n"
    "     if (cy < 1.0f) cy = 1.0f;         /* 爆炸点上边界夹紧：避免粒子出生即越界 */",
)
sub_once(
    r"         p     = &g_particles\[g_particle_count\];\n        speed = PSPEED_MIN \+\n                \(float\)\(rand\(\) % 100\) / 100\.0f \* \(PSPEED_MAX - PSPEED_MIN\);\n        p->vx   = \(\(float\)\(rand\(\) % 2000\) - 1000\.0f\) / 1000\.0f \* speed;\n        p->vy   = \(\(float\)\(rand\(\) % 2000\) - 1000\.0f\) / 1000\.0f \* speed;",
    "         p     = &g_particles[g_particle_count];\n"
    "        {\n"
    "            float u = (float)(rand() % 1000) / 1000.0f;\n"
    "            /* u*u 让速度偏向慢速：中心粒子密集，外圈才是快粒子 */\n"
    "            float speed = PSPEED_MIN + (PSPEED_MAX - PSPEED_MIN) * u * u;\n"
    "            int k = (base + i) % UNIT_STEPS;\n"
    "            p->vx = UNIT_X[k] * speed;\n"
    "            p->vy = UNIT_Y[k] * speed;\n"
    "        }",
)

# 4) 火箭尾焰：主点 '|' + 下方两格渐暗拖尾
sub_once(
    r"    px = \(int\)\(r->x \+ 0\.5f\);\n    py = \(int\)\(r->y \+ 0\.5f\);\n    draw_pixel\(px, py, 0, '\|'\);",
    "    px = (int)(r->x + 0.5f);\n"
    "    py = (int)(r->y + 0.5f);\n"
    "    draw_pixel(px, py, 0, '|');\n"
    "     /* 尾焰：火箭向上飞，下方两格用渐暗字符模拟拖尾 */\n"
    "     draw_pixel(px, py + 1, 2, 'o');\n"
    "     draw_pixel(px, py + 2, 4, ',');",
)

p.write_text(src, encoding="utf-8")
print("R3b visual tuning applied ->", p)
