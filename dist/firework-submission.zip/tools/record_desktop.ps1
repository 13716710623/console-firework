# Real desktop capture of the console window's CLIENT area (no title bar / borders).
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$exe  = Join-Path $root 'firework.exe'
$ff   = 'C:\Users\14495\AppData\Local\JianyingPro\Apps\11.5.3.14501\ffmpeg.exe'
$out  = Join-Path $root 'shots\firework-screen.mp4'
$secs = 8

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class W32 {
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
}
"@
[void][W32]::SetProcessDPIAware()

$proc = Start-Process -FilePath $exe -WorkingDirectory $root -PassThru
Start-Sleep -Seconds 2
$proc.Refresh()
$h = $proc.MainWindowHandle
if ($h -eq [IntPtr]::Zero) {
    $w = Get-Process -Id $proc.Id -ErrorAction SilentlyContinue
    if ($w) { $h = $w.MainWindowHandle }
}
if ($h -eq [IntPtr]::Zero) { $proc.Kill(); throw 'no window handle' }

[void][W32]::ShowWindow($h, 9)
[void][W32]::SetForegroundWindow($h)
Start-Sleep -Milliseconds 800

$cr = New-Object W32+RECT
[void][W32]::GetClientRect($h, [ref]$cr)
$origin = New-Object W32+POINT
$origin.X = 0
$origin.Y = 0
[void][W32]::ClientToScreen($h, [ref]$origin)

$wpx = $cr.Right - $cr.Left
$hpx = $cr.Bottom - $cr.Top
$wpx = $wpx - ($wpx % 2)
$hpx = $hpx - ($hpx % 2)
"client origin: $($origin.X),$($origin.Y) size ${wpx}x${hpx}"

$args = @(
    '-y','-hide_banner','-loglevel','error',
    '-f','gdigrab','-framerate','30','-draw_mouse','0',
    '-offset_x',"$($origin.X)",'-offset_y',"$($origin.Y)",
    '-video_size',"${wpx}x${hpx}",'-i','desktop',
    '-t',"$secs",
    '-c:v','h264_mf','-pix_fmt','yuv420p','-b:v','6M','-r','30',
    '-movflags','+faststart', $out
)
& $ff @args
$code = $LASTEXITCODE
Start-Sleep -Milliseconds 300
try { $proc.Kill() } catch {}
"ffmpeg exit=$code"
if (Test-Path $out) {
    $mb = [math]::Round((Get-Item $out).Length / 1MB, 2)
    "out -> $out ($mb MB)"
} else {
    "no output file"
}
