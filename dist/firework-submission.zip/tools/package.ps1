# 打包提交材料：dist/firework-submission.zip
# 说明：用系统自带 tar（bsdtar，-a 按扩展名生成 zip），避免 PowerShell 5.1
#       的 Compress-Archive / ZipFile 在中文路径下的兼容问题。
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$dist = Join-Path $root 'dist'
$stage = Join-Path $dist 'staging'
$zip = Join-Path $dist 'firework-submission.zip'

if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
if (Test-Path $zip) { Remove-Item $zip -Force }
New-Item -ItemType Directory -Force -Path $stage | Out-Null

foreach ($f in 'firework.c', 'Makefile', 'README.md') {
    Copy-Item (Join-Path $root $f) $stage -Force
}
foreach ($d in 'docs', 'shots', 'tools') {
    Copy-Item (Join-Path $root $d) $stage -Recurse -Force
}

# logs：只收 <=1MB 的文件，避免长跑抓帧把包撑大
$logDst = Join-Path $stage 'logs'
New-Item -ItemType Directory -Force -Path $logDst | Out-Null
$logRoot = Join-Path $root 'logs'
Get-ChildItem $logRoot -Recurse -File | Where-Object { $_.Length -le 1MB } | ForEach-Object {
    $rel = $_.FullName.Substring($logRoot.Length).TrimStart('\')
    $dst = Join-Path $logDst $rel
    New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
    Copy-Item $_.FullName $dst -Force
}

& tar -a -c -f $zip -C $stage .
if ($LASTEXITCODE -ne 0) { throw "tar failed: $LASTEXITCODE" }
Remove-Item $stage -Recurse -Force

Get-Item $zip | Select FullName, Length
