"""把程序输出的 ANSI 帧序列切成单帧文本，并渲染成 PNG / GIF（用于测试记录与录屏替代）。

用法：
  python capture_frames.py <raw.txt> <outdir> [--gif out.gif] [--fps 20]
"""
import os
import re
import sys
import argparse

ANSI_HOME = re.compile(r"\x1b\[H|\x1b\[1;1H")
ANSI_ANY = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
CLEAR = re.compile(r"\x1b\[2J")

# 字符亮度 -> 颜色（暖色烟花；@ 最亮，. 最暗但不至于看不见）
PALETTE = [
    (255, 255, 236),   # @
    (255, 232, 170),   # O
    (255, 205, 125),   # o
    (245, 170, 95),    # *
    (215, 130, 80),    # ,
    (180, 105, 80),    # .
]


def split_frames(raw: str):
    raw = raw.replace("\r\n", "\n").replace("\r", "\n")
    frames = []
    for part in ANSI_HOME.split(raw):
        clean = CLEAR.sub("", ANSI_ANY.sub("", part))
        lines = [ln.rstrip() for ln in clean.split("\n")]
        while lines and not lines[-1].strip():
            lines.pop()
        if lines:
            frames.append(lines)
    return frames


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw")
    ap.add_argument("outdir")
    ap.add_argument("--gif", default=None)
    ap.add_argument("--fps", type=int, default=20)
    ap.add_argument("--max-frames", type=int, default=0)
    args = ap.parse_args()

    from PIL import Image, ImageDraw, ImageFont

    raw = open(args.raw, encoding="utf-8", errors="replace").read()
    frames = split_frames(raw)
    if args.max_frames:
        frames = frames[: args.max_frames]
    if not frames:
        print("no frames parsed")
        return 1

    os.makedirs(args.outdir, exist_ok=True)
    height = max(len(f) for f in frames)
    width = max((max((len(l) for l in f), default=0) for f in frames), default=0)
    print(f"frames={len(frames)} rows={height} cols={width}")

    font = None
    for cand in (
        r"C:\Windows\Fonts\consola.ttf",
        r"C:\Windows\Fonts\cour.ttf",
        r"C:\Windows\Fonts\msyh.ttc",
    ):
        if os.path.exists(cand):
            font = ImageFont.truetype(cand, 16)
            break
    if font is None:
        font = ImageFont.load_default()

    cw, ch = 10, 18
    margin = 8
    img_w = width * cw + margin * 2
    img_h = height * ch + margin * 2

    images = []
    for idx, frame in enumerate(frames):
        img = Image.new("RGB", (img_w, img_h), (6, 8, 18))
        d = ImageDraw.Draw(img)
        for r, line in enumerate(frame):
            for c, ch_ in enumerate(line):
                if ch_ == " ":
                    continue
                level = "@Oo*,.".find(ch_)
                if level < 0:
                    level = 5
                d.text((margin + c * cw, margin + r * ch), ch_, font=font,
                       fill=PALETTE[level])
        images.append(img)
        if idx in (0, len(frames) // 2, len(frames) - 1):
            img.save(os.path.join(args.outdir, f"frame_{idx:03d}.png"))

    if args.gif and len(images) > 1:
        images[0].save(
            args.gif,
            save_all=True,
            append_images=images[1:],
            duration=int(1000 / args.fps),
            loop=0,
        )
        print("gif ->", args.gif)
    return 0


if __name__ == "__main__":
    sys.exit(main())
