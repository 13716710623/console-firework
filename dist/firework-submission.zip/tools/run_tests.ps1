# 自动化测试：编译 + 多场景运行 + 退出码/输出检查
# 用法： powershell -ExecutionPolicy Bypass -File tools\run_tests.ps1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$gcc  = 'C:\Users\14495\AppData\Local\Programs\RedPanda-CPP\mingw64\bin\gcc.exe'
$log  = Join-Path $root 'logs'
New-Item -ItemType Directory -Force -Path $log | Out-Null

$fail = 0
function Step($name, [scriptblock]$body) {
    Write-Host "`n=== $name ===" -ForegroundColor Cyan
    try { & $body; if ($LASTEXITCODE -ne 0 -and $null -ne $LASTEXITCODE) { throw "exit=$LASTEXITCODE" } }
    catch { Write-Host "FAIL: $name -> $_" -ForegroundColor Red; $script:fail++ }
}

Step 'compile (-Wall -Wextra, zero-warning check)' {
    $errFile = Join-Path $log 'build.stderr.txt'
    & $gcc '-std=c99' '-O2' '-Wall' '-Wextra' (Join-Path $root 'firework.c') '-o' (Join-Path $root 'firework.exe') 2> $errFile
    $warn = Get-Content $errFile -Raw -ErrorAction SilentlyContinue
    if ($warn -and $warn.Trim()) { Write-Host $warn -ForegroundColor Yellow; throw 'compiler diagnostics present' }
    Write-Host 'compile ok, 0 warnings' -ForegroundColor Green
}

Step 'run 300 frames @60fps seed=20261119' {
    $out = Join-Path $log 'run300.raw.txt'
    $sw = [Diagnostics.Stopwatch]::StartNew()
    & (Join-Path $root 'firework.exe') --frames 300 --fps 60 --seed 20261119 *> $out
    $sw.Stop()
    "duration=$([int]$sw.Elapsed.TotalMilliseconds)ms size=$((Get-Item $out).Length)B esc=$(([regex]::Matches((Get-Content $out -Raw), [char]27)).Count)"
    if ((Get-Item $out).Length -lt 1000) { throw 'output too small' }
}

Step 'run 60 frames @30fps (deterministic same seed twice)' {
    $a = Join-Path $log 'det_a.raw.txt'; $b = Join-Path $log 'det_b.raw.txt'
    & (Join-Path $root 'firework.exe') --frames 60 --fps 240 --seed 777 *> $a
    & (Join-Path $root 'firework.exe') --frames 60 --fps 240 --seed 777 *> $b
    $h1 = (Get-FileHash $a -Algorithm SHA256).Hash
    $h2 = (Get-FileHash $b -Algorithm SHA256).Hash
    "hash1=$h1"; "hash2=$h2"
    if ($h1 -ne $h2) { throw 'same seed produced different frames' }
}

Step 'edge: --frames 1' {
    & (Join-Path $root 'firework.exe') --frames 1 --fps 240 --seed 1 *> (Join-Path $log 'edge1.raw.txt')
}

Step 'edge: --frames 0 with 2s timeout (infinite mode must keep running)' {
    $p = Start-Process -FilePath (Join-Path $root 'firework.exe') -ArgumentList @('--fps','120','--seed','5') -NoNewWindow -PassThru -RedirectStandardOutput (Join-Path $log 'inf.raw.txt')
    Start-Sleep -Seconds 2
    if ($p.HasExited) { throw 'infinite mode exited unexpectedly' }
    $p.Kill(); Write-Host 'still running after 2s, killed ok' -ForegroundColor Green
}

Write-Host "`n===== RESULT: $(if ($fail -eq 0) { 'ALL PASS' } else { "$fail FAILED" }) =====" -ForegroundColor $(if ($fail -eq 0) { 'Green' } else { 'Red' })
exit $fail
