"""生成微信可直接发送的两个文件：MP4（聊天里点开即播）与 GIF（当图片发，自动循环）。

用法：
  python make_wechat.py <raw.txt> <outdir> --ffmpeg <ffmpeg.exe> [--fps 30]
"""
import argparse
import os
import re
import shutil
import subprocess
import sys

ANSI_HOME = re.compile(r"\x1b\[H|\x1b\[1;1H")
ANSI_ANY = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
CLEAR = re.compile(r"\x1b\[2J")

PALETTE = [
    (255, 255, 236),   # @
    (255, 232, 170),   # O
    (255, 205, 125),   # o
    (245, 170, 95),    # *
    (215, 130, 80),    # ,
    (180, 105, 80),    # .
]


def split_frames(raw: str):
    raw = raw.replace("\r\n", "\n").replace("\r", "\n")
    frames = []
    for part in ANSI_HOME.split(raw):
        clean = CLEAR.sub("", ANSI_ANY.sub("", part))
        lines = [ln.rstrip() for ln in clean.split("\n")]
        while lines and not lines[-1].strip():
            lines.pop()
        if lines:
            frames.append(lines)
    return frames


def render_frames(frames, outdir, cw=20, ch=36, margin=24, bg=(6, 8, 18)):
    from PIL import Image, ImageDraw, ImageFont

    font = ImageFont.truetype(r"C:\Windows\Fonts\consola.ttf", 32)
    rows = max(len(f) for f in frames)
    cols = max(max((len(l) for l in f), default=0) for f in frames)
    W = cols * cw + margin * 2
    H = rows * ch + margin * 2
    W -= W % 2
    H -= H % 2
    os.makedirs(outdir, exist_ok=True)
    for idx, frame in enumerate(frames):
        img = Image.new("RGB", (W, H), bg)
        d = ImageDraw.Draw(img)
        for r, line in enumerate(frame):
            for c, ch_ in enumerate(line):
                if ch_ == " ":
                    continue
                level = "@Oo*,.".find(ch_)
                if level < 0:
                    level = 5
                d.text((margin + c * cw, margin + r * ch), ch_, font=font, fill=PALETTE[level])
        img.save(os.path.join(outdir, f"w_{idx:04d}.png"))
    return W, H


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw")
    ap.add_argument("outdir")
    ap.add_argument("--ffmpeg", required=True)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--max-frames", type=int, default=300)
    args = ap.parse_args()

    raw = open(args.raw, encoding="utf-8", errors="replace").read()
    frames = split_frames(raw)
    if args.max_frames:
        frames = frames[: args.max_frames]
    if not frames:
        print("no frames")
        return 1

    out = args.outdir
    os.makedirs(out, exist_ok=True)
    fd = os.path.join(out, "_frames")
    if os.path.isdir(fd):
        shutil.rmtree(fd)
    W, H = render_frames(frames, fd)
    print(f"frames={len(frames)} render={W}x{H}")

    mp4 = os.path.join(out, "firework-wechat.mp4")
    cmd = [
        args.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-framerate", str(args.fps), "-i", os.path.join(fd, "w_%04d.png"),
        "-vf", "scale=1080:-2:flags=lanczos",
        "-c:v", "h264_mf", "-pix_fmt", "yuv420p", "-b:v", "5M",
        "-r", str(args.fps), "-movflags", "+faststart",
        "-an", mp4,
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(mp4):
        print("h264_mf failed, fallback mpeg4:", r.stderr[-300:])
        cmd[cmd.index("h264_mf")] = "mpeg4"
        cmd[cmd.index("mpeg4") + 1:cmd.index("mpeg4") + 1] = ["-q:v", "4"]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            print("mp4 failed:", r.stderr[-300:])
            return 1
    print("mp4 ->", mp4, round(os.path.getsize(mp4) / 1048576, 2), "MB")

    # GIF：隔帧取，宽度 540，调色板优化
    gif = os.path.join(out, "firework-wechat.gif")
    gcmd = [
        args.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
        "-framerate", str(args.fps), "-i", os.path.join(fd, "w_%04d.png"),
        "-vf", f"fps={max(10, args.fps // 2)},scale=540:-1:flags=lanczos,split[a][b];[a]palettegen=max_colors=128[p];[b][p]paletteuse=dither=sierra2_4a",
        "-loop", "0", gif,
    ]
    r = subprocess.run(gcmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(gif):
        print("gif failed:", r.stderr[-300:])
        return 1
    print("gif ->", gif, round(os.path.getsize(gif) / 1048576, 2), "MB")

    if not os.environ.get("KEEP_FRAMES"):
        shutil.rmtree(fd)
    return 0


if __name__ == "__main__":
    sys.exit(main())
