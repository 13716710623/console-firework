"""R6：粒子特效精细化——移动拖尾、上升烟迹、爆心闪光、空气阻力。"""
from pathlib import Path

p = Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c")
s = p.read_text(encoding="utf-8")


def replace_once(old, new):
    global s
    assert s.count(old) == 1, (old[:60], s.count(old))
    s = s.replace(old, new)


# 1) 爆心闪光：爆炸瞬间 8 颗短命高亮粒子，形成 5~9 帧的亮核
replace_once(
    "    for (k = 0; k < dirs; k++) {\n        int dir = (base_dir + k * RAY_DIRS / dirs) % RAY_DIRS;",
    "    /* 爆心闪光：几帧的高亮核心，模拟爆炸瞬间的强光 */\n"
    "    for (k = 0; k < 8; k++) {\n"
    "        int fd = rand() % UNIT_STEPS;\n"
    "        float fsp = 0.03f + (float)(rand() % 100) / 2500.0f;\n"
    "        (void)spawn_particle(cx, cy, cx, cy, UNIT_X[fd] * fsp, UNIT_Y[fd] * fsp,\n"
    "                             5 + rand() % 5, KIND_NORMAL, 0);\n"
    "    }\n"
    "    for (k = 0; k < dirs; k++) {\n        int dir = (base_dir + k * RAY_DIRS / dirs) % RAY_DIRS;",
)

# 2) 上升烟迹：火箭每帧抛一颗短命暗火星
replace_once(
    "    r->vy *= ROCKET_DRAG;\n    /* 到达目标高度或速度趋零或飞出顶部 -> 爆炸 */",
    "    r->vy *= ROCKET_DRAG;\n"
    "    /* 上升烟迹：每帧抛一颗短命暗火星，形成连续的发射轨迹 */\n"
    "    if (r->y > 0.0f && r->y < (float)rows && r->x > 0.0f && r->x < (float)cols) {\n"
    "        (void)spawn_particle(r->x, r->y, r->x, r->y + 1.0f,\n"
    "                             ((float)(rand() % 100) - 50.0f) / 400.0f,\n"
    "                             0.04f + (float)(rand() % 100) / 1500.0f,\n"
    "                             6 + rand() % 8, KIND_NORMAL, 3);\n"
    "    }\n"
    "    /* 到达目标高度或速度趋零或飞出顶部 -> 爆炸 */",
)

# 3) 空气阻力：粒子速度逐帧衰减，末段更飘
replace_once(
    "        q->x   += q->vx;\n        q->y   += q->vy;",
    "        q->vx  *= 0.988f;   /* 空气阻力：爆炸初期快、末段飘 */\n"
    "        q->vy  *= 0.988f;\n"
    "        q->x   += q->vx;\n        q->y   += q->vy;",
)

# 4) 移动拖尾：沿速度反方向补一个更暗的字符
replace_once(
    "        if (b > NUM_BRIGHT - 1) b = NUM_BRIGHT - 1;\n        draw_pixel(px, py, b, BRIGHT_CHARS[b]);",
    "        if (b > NUM_BRIGHT - 1) b = NUM_BRIGHT - 1;\n"
    "        /* 移动拖尾：沿速度反方向补一个更暗的字符，形成速度线 */\n"
    "        if (q->vx > 0.12f || q->vx < -0.12f || q->vy > 0.12f || q->vy < -0.12f) {\n"
    "            int tx = px - (int)(q->vx * 1.6f);\n"
    "            int ty = py - (int)(q->vy * 1.6f);\n"
    "            int tb = b + 2;\n"
    "            if (tb > NUM_BRIGHT - 1) tb = NUM_BRIGHT - 1;\n"
    "            if (tx != px || ty != py) draw_pixel(tx, ty, tb, BRIGHT_CHARS[tb]);\n"
    "        }\n"
    "        draw_pixel(px, py, b, BRIGHT_CHARS[b]);",
)

p.write_text(s, encoding="utf-8")
print("R6 particle detail patch applied")
