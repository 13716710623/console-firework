﻿/*
 * firework.c — 多烟花并发控制台动画（R2）
 * 平台：Windows(MinGW) / POSIX，C99 标准库 + 条件编译平台 API
 * 构建：gcc firework.c -o firework -Wall -Wextra（零警告）
 */

/* POSIX 特性宏：确保 nanosleep / ioctl 可见（仅非 Windows） */
#if !defined(_WIN32) && !defined(_POSIX_C_SOURCE)
  #define _POSIX_C_SOURCE 200112L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

 /* ===== 平台头文件（条件编译） ===== */
 #ifdef _WIN32
   #include <windows.h>
  #include <conio.h>            /* _kbhit 非阻塞按键检测 */
 #else
   #include <unistd.h>
   #include <sys/ioctl.h>
  #include <sys/time.h>         /* gettimeofday 高精度计时 */
   #include <termios.h>
 #endif

/* ===== 常量宏（禁止魔法数字） ===== */
#define MAX_PARTICLES   4096          /* 粒子数组容量 */
#define MAX_COLS        200           /* 画布最大列数 */
#define MAX_ROWS        60            /* 画布最大行数 */
#define DEFAULT_FPS     30            /* 默认帧率 */
#define FALLBACK_COLS   80            /* 读取失败时回退列数 */
#define FALLBACK_ROWS   24            /* 读取失败时回退行数 */
#define MIN_PARTICLES   80            /* 爆炸最少粒子数 */
#define MAX_EXPLOSION   200           /* 爆炸最多粒子数 */
#define MIN_LIFE        40            /* 粒子最短寿命（帧） */
#define MAX_LIFE        80            /* 粒子最长寿命（帧） */
#define ROCKET_DRAG     0.99f         /* 火箭上升阻力系数 */
#define ROCKET_VY_MIN   0.8f          /* 火箭最小初速 */
 #define ROCKET_VY_MAX   1.5f          /* 火箭最大初速 */
 #define ROCKET_STOP     0.05f         /* 火箭近乎停止的阈值 */
 #define MAX_ROCKETS        6          /* 同时存在的最大烟花数 */
 #define LAUNCH_INTERVAL_MIN 20        /* 发射间隔最小帧数 */
 #define LAUNCH_INTERVAL_MAX 60        /* 发射间隔最大帧数 */
 #define GRAVITY         0.04f         /* 粒子重力加速度 */
#define PSPEED_MIN      0.3f          /* 粒子最小初速 */
#define PSPEED_MAX      1.2f          /* 粒子最大初速 */
#define NUM_BRIGHT      6             /* 亮度等级数 */
#define FRAMEBUF_SIZE   (MAX_ROWS * (MAX_COLS + 1) + 32)

/* 亮度距离平方阈值（离爆炸中心越近越亮） */
#define BDIST0   4.0f                 /* d < 2.0  -> '@' */
#define BDIST1   16.0f                /* d < 4.0  -> 'O' */
#define BDIST2   36.0f                /* d < 6.0  -> 'o' */
#define BDIST3   81.0f                /* d < 9.0  -> '*' */
#define BDIST4   144.0f               /* d < 12.0 -> ',' */
/* d >= 12.0 -> '.' */

/* ===== 数据结构 ===== */

/* 粒子：爆炸后产生，带速度/重力/寿命/爆炸中心 */
typedef struct {
    float x, y;       /* 当前坐标（列, 行） */
    float vx, vy;     /* 速度 */
    int   life;       /* 剩余寿命（帧） */
    float cx, cy;     /* 爆炸中心坐标（用于亮度计算） */
} Particle;

/* 火箭：上升阶段，到达目标高度后爆炸 */
typedef struct {
    float x, y;       /* 当前坐标 */
    float vx, vy;     /* 速度 */
    float target_y;   /* 目标高度（行号，越小越高） */
    int   active;     /* 是否在飞行中 */
} Rocket;

 /* ===== 全局静态数组 ===== */
 static Particle g_particles[MAX_PARTICLES];
 static int      g_particle_count = 0;
 static Rocket   g_rockets[MAX_ROCKETS]; /* 烟箭数组（并发管理） */
 static int      g_launch_cooldown = 0;  /* 距下次发射的帧数 */
 static long     g_drop_count = 0;       /* 满上限丢弃的粒子计数 */
 static int      g_ansi_mode = 0;        /* --ansi：强制 ANSI 光标归位 */
 static char     g_canvas[MAX_ROWS][MAX_COLS];
 static int      g_bright[MAX_ROWS][MAX_COLS];
 static char     g_framebuf[FRAMEBUF_SIZE];

 #ifdef _WIN32
 static CONSOLE_CURSOR_INFO g_orig_cursor; /* 进入前光标信息，用于恢复 */
 #else
 static struct termios g_orig_termios;     /* 进入前终端属性，用于恢复 */
 static int g_term_raw = 0;                /* 是否已切到非阻塞模式 */
 #endif

/* 亮度字符表：索引越小越亮 @ O o * , . */
static const char BRIGHT_CHARS[NUM_BRIGHT] = {'@', 'O', 'o', '*', ',', '.'};

/* ===== 平台抽象函数 ===== */

/*
 * 获取控制台实际尺寸。
 * 参数：cols/rows 输出当前列数和行数。
 * 边界：读取失败时回退 80x24；过小时回退；上限不超过 MAX_COLS/MAX_ROWS。
 */
static void get_console_size(int *cols, int *rows)
{
    *cols = FALLBACK_COLS;
    *rows = FALLBACK_ROWS;

#ifdef _WIN32
    {
        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
        CONSOLE_SCREEN_BUFFER_INFO info;
        if (h != INVALID_HANDLE_VALUE && GetConsoleScreenBufferInfo(h, &info)) {
            *cols = info.srWindow.Right - info.srWindow.Left + 1;
            *rows = info.srWindow.Bottom - info.srWindow.Top + 1;
        }
    }
#else
    {
        struct winsize ws;
        if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0) {
            *cols = ws.ws_col;
            *rows = ws.ws_row;
        }
    }
#endif

    if (*cols < 10)        *cols = FALLBACK_COLS;
    if (*rows < 5)         *rows = FALLBACK_ROWS;
    if (*cols > MAX_COLS)  *cols = MAX_COLS;
    if (*rows > MAX_ROWS)  *rows = MAX_ROWS;
}

/*
 * 跨平台毫秒级休眠，不做忙等。
 * 参数：ms - 休眠毫秒数（<=0 时直接返回）。
 */
static void platform_sleep_ms(int ms)
{
    if (ms <= 0) return;
#ifdef _WIN32
    Sleep((DWORD)ms);
#else
    {
        struct timespec ts;
        ts.tv_sec  = (time_t)(ms / 1000);
         ts.tv_nsec = (long)((ms % 1000) * 1000000L);
         nanosleep(&ts, NULL);
     }
 #endif
 }

 /*
  * 获取高精度当前时间（毫秒），用于帧率稳定计算。
  * Windows 用 QueryPerformanceCounter，POSIX 用 gettimeofday。
  */
 static double get_time_ms(void)
 {
 #ifdef _WIN32
     static LARGE_INTEGER freq = {0};
     LARGE_INTEGER now;
     if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
     QueryPerformanceCounter(&now);
     return (double)now.QuadPart * 1000.0 / (double)freq.QuadPart;
 #else
     struct timeval tv;
     gettimeofday(&tv, NULL);
     return (double)tv.tv_sec * 1000.0 + (double)tv.tv_usec / 1000.0;
 #endif
 }

 /*
  * 帧率稳定：按本帧实际耗时休眠剩余时间，渲染耗时计入，非固定 sleep。
  * 参数：start_ms - 本帧开始时刻；frame_interval - 目标帧时长(毫秒)。
  */
 static void sync_frame(double start_ms, int frame_interval)
 {
     double elapsed = get_time_ms() - start_ms;
     int remain = frame_interval - (int)elapsed;
     platform_sleep_ms(remain);
 }

 /*
  * 光标归位到左上角 (0,0)，用于双缓冲覆盖式渲染。
  * --ansi 模式统一走 ANSI \033[H（便于重定向抓帧测试）；
  * 否则 Windows 用 SetConsoleCursorPosition，POSIX 用 ANSI。
  */
 static void cursor_home(void)
 {
     if (g_ansi_mode) {
         fputs("\033[H", stdout);
         return;
     }
 #ifdef _WIN32
     HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
     if (h != INVALID_HANDLE_VALUE) {
        COORD pos = {0, 0};
        SetConsoleCursorPosition(h, pos);
    }
 #else
     fputs("\033[H", stdout);
 #endif
 }

 /*
  * 隐藏光标：Windows 用 SetConsoleCursorInfo，POSIX 用 ANSI \033[?25l。
  */
 static void hide_cursor(void)
 {
 #ifdef _WIN32
     HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
     CONSOLE_CURSOR_INFO ci;
     if (h != INVALID_HANDLE_VALUE && GetConsoleCursorInfo(h, &g_orig_cursor)) {
         ci = g_orig_cursor;
         ci.bVisible = FALSE;
         SetConsoleCursorInfo(h, &ci);
     }
 #else
     fputs("\033[?25l", stdout);
     fflush(stdout);
 #endif
 }

 /*
  * 显示光标：恢复进入循环前的光标状态。
  */
 static void show_cursor(void)
 {
 #ifdef _WIN32
     HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
     if (h != INVALID_HANDLE_VALUE) {
         SetConsoleCursorInfo(h, &g_orig_cursor);
     }
 #else
     fputs("\033[?25h", stdout);
     fflush(stdout);
 #endif
 }

 /*
  * 初始化终端交互：POSIX 设置非阻塞读取（VMIN=0/VTIME=0）。
  * Windows 无需特殊设置，_kbhit 本身非阻塞。
  */
 static void init_terminal(void)
 {
 #ifndef _WIN32
     struct termios t;
     if (tcgetattr(STDIN_FILENO, &g_orig_termios) == 0) {
         t = g_orig_termios;
         t.c_lflag &= ~(ICANON | ECHO);
         t.c_cc[VMIN] = 0;
         t.c_cc[VTIME] = 0;
         tcsetattr(STDIN_FILENO, TCSANOW, &t);
         g_term_raw = 1;
     }
 #endif
 }

 /*
  * 恢复终端原始属性（POSIX）；退出前调用。
  */
 static void restore_terminal(void)
 {
 #ifndef _WIN32
     if (g_term_raw) {
         tcsetattr(STDIN_FILENO, TCSANOW, &g_orig_termios);
         g_term_raw = 0;
     }
 #endif
 }

 /*
  * 非阻塞检测按键：有按键返回 1，否则返回 0（绝不阻塞主循环）。
  */
 static int check_key_pressed(void)
 {
 #ifdef _WIN32
     return _kbhit() ? 1 : 0;
 #else
     char c;
     ssize_t n = read(STDIN_FILENO, &c, 1);
     return (n > 0) ? 1 : 0;
 #endif
 }

/*
 * 清屏：程序启动和退出时调用，避免残影。
 * Windows 用 FillConsoleOutputCharacter，POSIX 用 ANSI \033[2J。
 */
static void clear_screen(void)
{
#ifdef _WIN32
    {
        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
        CONSOLE_SCREEN_BUFFER_INFO info;
        DWORD written;
        if (h != INVALID_HANDLE_VALUE && GetConsoleScreenBufferInfo(h, &info)) {
            COORD origin = {0, 0};
            DWORD cells = (DWORD)info.dwSize.X * (DWORD)info.dwSize.Y;
            FillConsoleOutputCharacter(h, ' ', cells, origin, &written);
            FillConsoleOutputAttribute(h, info.wAttributes, cells, origin, &written);
            SetConsoleCursorPosition(h, origin);
        }
    }
#else
    fputs("\033[2J\033[H", stdout);
    fflush(stdout);
#endif
}

/* ===== 参数解析 ===== */

/*
 * 解析命令行参数 --frames / --fps / --seed。
 * 参数：argc/argv 来自 main；frames/fps/seed 为输出。
 * 默认：frames=0(无限)，fps=30，seed=0(后续用 time(NULL))。
 * 负 frames 视为 0。
 */
 static void parse_args(int argc, char **argv, int *frames, int *fps,
                        unsigned *seed, int *ansi)
 {
     int i;
     *frames = 0;
     *fps    = DEFAULT_FPS;
     *seed   = 0;
     *ansi   = 0;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--frames") == 0 && i + 1 < argc) {
            *frames = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--fps") == 0 && i + 1 < argc) {
            *fps = atoi(argv[++i]);
         } else if (strcmp(argv[i], "--seed") == 0 && i + 1 < argc) {
             *seed = (unsigned)strtoul(argv[++i], NULL, 10);
         } else if (strcmp(argv[i], "--ansi") == 0) {
             *ansi = 1;
         }
    }
    if (*frames < 0) *frames = 0;
    if (*fps < 1)    *fps = DEFAULT_FPS;
}

/* ===== 亮度计算 ===== */

/*
 * 根据粒子到爆炸中心的距离平方计算亮度等级。
 * 参数：dx/dy - 粒子位置与爆炸中心的偏移量。
 * 返回：0~5，0 最亮(@)，5 最暗(.)。
 */
static int compute_brightness(float dx, float dy)
{
    float d2 = dx * dx + dy * dy;
    if (d2 < BDIST0) return 0;  /* '@' */
    if (d2 < BDIST1) return 1;  /* 'O' */
    if (d2 < BDIST2) return 2;  /* 'o' */
    if (d2 < BDIST3) return 3;  /* '*' */
    if (d2 < BDIST4) return 4;  /* ',' */
    return 5;                   /* '.' */
}

/* ===== 画布操作 ===== */

/*
 * 清空画布：填充空格，亮度标记设为最高值(空白)。
 * 参数：cols/rows - 画布有效尺寸。
 */
static void clear_canvas(int cols, int rows)
{
    int y, x;
    for (y = 0; y < rows; y++) {
        for (x = 0; x < cols; x++) {
            g_canvas[y][x] = ' ';
            g_bright[y][x] = NUM_BRIGHT;
        }
    }
}

/*
 * 向画布写入一个像素，带边界校验和亮度优先级。
 * 参数：x/y - 整数坐标；brightness - 亮度等级(0最亮)；ch - 字符。
 * 边界：x/y 越界时直接返回；更亮的像素覆盖更暗的。
 */
static void draw_pixel(int x, int y, int brightness, char ch)
{
    if (x < 0 || x >= MAX_COLS || y < 0 || y >= MAX_ROWS) return;
    if (brightness < g_bright[y][x]) {
        g_bright[y][x] = brightness;
        g_canvas[y][x] = ch;
    }
}

/* ===== 火箭与粒子逻辑 ===== */

 /*
  * 初始化火箭：从底部随机位置以随机初速向上飞行。
  * 参数：r - 火箭结构体指针；cols/rows - 画布尺寸。
  */
 static void init_rocket(Rocket *r, int cols, int rows)
 {
     int launch_x = cols / 4 + rand() % (cols / 2 + 1);
     r->x        = (float)launch_x;
    r->y        = (float)(rows - 1);
    r->vx       = ((float)(rand() % 100) - 50.0f) / 200.0f;
    r->vy       = -(ROCKET_VY_MIN +
                    (float)(rand() % 100) / 100.0f * (ROCKET_VY_MAX - ROCKET_VY_MIN));
     r->target_y = (float)(rows / 5 + rand() % (rows / 3 + 1));
     r->active   = 1;
 }

 /*
  * 发射火箭：在烟箭数组中寻找空闲槽位发射，无空位则跳过。
  * 参数：cols/rows - 画布尺寸。
  */
 static void launch_rocket(int cols, int rows)
 {
     int i;
     for (i = 0; i < MAX_ROCKETS; i++) {
         if (!g_rockets[i].active) {
             init_rocket(&g_rockets[i], cols, rows);
             return;
         }
     }
 }

/*
  * 爆炸：在指定位置生成 80~200 个粒子，径向扩散。
  * 参数：cx/cy - 爆炸中心坐标。
  * 边界：粒子数不超过 MAX_PARTICLES，满上限时丢弃并累计 g_drop_count。
  */
 static void explode(float cx, float cy)
 {
     int n = MIN_PARTICLES + rand() % (MAX_EXPLOSION - MIN_PARTICLES + 1);
     int i;
     for (i = 0; i < n; i++) {
         Particle *p;
         float speed;
         if (g_particle_count >= MAX_PARTICLES) {
             g_drop_count++;          /* 满上限：丢弃多余粒子并计数 */
             continue;
         }
         p     = &g_particles[g_particle_count];
        speed = PSPEED_MIN +
                (float)(rand() % 100) / 100.0f * (PSPEED_MAX - PSPEED_MIN);
        p->vx   = ((float)(rand() % 2000) - 1000.0f) / 1000.0f * speed;
        p->vy   = ((float)(rand() % 2000) - 1000.0f) / 1000.0f * speed;
        p->x    = cx;
        p->y    = cy;
        p->cx   = cx;
        p->cy   = cy;
        p->life = MIN_LIFE + rand() % (MAX_LIFE - MIN_LIFE + 1);
        g_particle_count++;
    }
}

/*
 * 更新火箭：移动、施加阻力减速、检测爆炸条件。
 * 参数：r - 火箭；cols/rows - 画布尺寸。
 * 到达目标高度、速度趋零、或飞出上边界 -> 爆炸；
 * 飞出左右/下边界 -> 直接消失。
 */
static void update_rocket(Rocket *r, int cols, int rows)
{
    if (!r->active) return;
    r->x += r->vx;
    r->y += r->vy;
    r->vy *= ROCKET_DRAG;
    /* 到达目标高度或速度趋零或飞出顶部 -> 爆炸 */
    if (r->y <= r->target_y || r->vy >= -ROCKET_STOP || r->y < 0.0f) {
        r->active = 0;
        explode(r->x, r->y);
        return;
    }
    /* 飞出左右或下边界 -> 直接消失 */
    if (r->x < 0.0f || r->x >= (float)cols || r->y >= (float)rows) {
        r->active = 0;
    }
}

/*
 * 更新所有粒子：移动、施加重力、递减寿命、紧凑删除。
 * 参数：cols/rows - 画布尺寸。
 * 寿命<=0 或飞出边界时用「尾部覆盖 + count--」删除。
 */
static void update_particles(int cols, int rows)
{
    int i = 0;
    while (i < g_particle_count) {
        Particle *p = &g_particles[i];
        p->x   += p->vx;
        p->y   += p->vy;
        p->vy  += GRAVITY;
        p->life--;
        if (p->life <= 0 ||
            p->x < 0.0f || p->x >= (float)cols ||
            p->y < 0.0f || p->y >= (float)rows) {
            /* 尾部元素覆盖当前位置，count-- */
            g_particles[i] = g_particles[g_particle_count - 1];
            g_particle_count--;
            /* 不递增 i：继续检查新移入的元素 */
        } else {
            i++;
        }
    }
}

/* ===== 渲染 ===== */

/*
 * 渲染火箭到画布（上升阶段可见，用 '|' 表示）。
 * 参数：r - 火箭结构体（只读）。
 */
static void render_rocket(const Rocket *r)
{
    int px, py;
    if (!r->active) return;
    px = (int)(r->x + 0.5f);
    py = (int)(r->y + 0.5f);
    draw_pixel(px, py, 0, '|');
}

/*
 * 渲染所有粒子到画布，按距爆炸中心距离映射亮度字符。
 * 参数：cols/rows - 画布尺寸（用于跳过越界粒子）。
 */
static void render_particles(int cols, int rows)
{
    int i;
    for (i = 0; i < g_particle_count; i++) {
        Particle *p = &g_particles[i];
        int px = (int)(p->x + 0.5f);
        int py = (int)(p->y + 0.5f);
        float dx, dy;
        int b;
        if (px < 0 || px >= cols || py < 0 || py >= rows) continue;
        dx = p->x - p->cx;
        dy = p->y - p->cy;
        b  = compute_brightness(dx, dy);
        draw_pixel(px, py, b, BRIGHT_CHARS[b]);
    }
}

/*
 * 构建帧缓冲并一次性输出（双缓冲）。
 * 参数：cols/rows - 画布有效尺寸。
 * 先 cursor_home 归位，再 fputs 整帧，最后 fflush。
 */
static void render_frame(int cols, int rows)
{
    int y;
    char *buf = g_framebuf;
    for (y = 0; y < rows; y++) {
        memcpy(buf, g_canvas[y], (size_t)cols);
        buf += cols;
        if (y < rows - 1) {
            *buf++ = '\n';
        }
    }
    *buf = '\0';
    cursor_home();
    fputs(g_framebuf, stdout);
    fflush(stdout);
}

/* ===== 主循环 ===== */

/*
 * 入口：解析参数 -> 初始化 -> 主循环（更新->渲染->休眠）-> 清理退出。
 */
int main(int argc, char **argv)
{
    int frames, fps, frame_interval;
    unsigned seed;
     int cols, rows;
     int frame_count = 0;
     int i;

     parse_args(argc, argv, &frames, &fps, &seed, &g_ansi_mode);
     if (seed == 0) seed = (unsigned)time(NULL);
     srand(seed);

    get_console_size(&cols, &rows);
     frame_interval = 1000 / fps;

     init_terminal();
     hide_cursor();
     clear_screen();

     /* 主循环：按键检测 -> 更新 -> 渲染 -> 帧同步 */
     while (frames == 0 || frame_count < frames) {
         double start_ms;

         /* --- 交互退出：任意键非阻塞检测 --- */
         if (check_key_pressed()) break;

         start_ms = get_time_ms();

         /* --- 更新阶段 --- */
         /* 多烟花发射调度：冷却到 0 时找空位发射并重置随机间隔 */
         if (g_launch_cooldown <= 0) {
             launch_rocket(cols, rows);
             g_launch_cooldown = LAUNCH_INTERVAL_MIN +
                 rand() % (LAUNCH_INTERVAL_MAX - LAUNCH_INTERVAL_MIN + 1);
         } else {
             g_launch_cooldown--;
         }
         for (i = 0; i < MAX_ROCKETS; i++) {
             update_rocket(&g_rockets[i], cols, rows);
         }
         update_particles(cols, rows);

         /* --- 渲染阶段 --- */
         clear_canvas(cols, rows);
         for (i = 0; i < MAX_ROCKETS; i++) {
             render_rocket(&g_rockets[i]);
         }
         render_particles(cols, rows);
         render_frame(cols, rows);

         /* --- 帧同步：按实际耗时休眠剩余时间 --- */
         sync_frame(start_ms, frame_interval);
         frame_count++;
     }

     /* 清理退出：恢复终端、显示光标、清屏 */
     restore_terminal();
     show_cursor();
     clear_screen();
     return 0;
 }
