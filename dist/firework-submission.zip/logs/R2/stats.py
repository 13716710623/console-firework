﻿import sys, re, collections
raw=open(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\logs\R2\cap240.txt",encoding="utf-8",errors="replace").read()
frames=[f for f in raw.split("\x1b[H") if f.strip()]
print("frames:",len(frames))
counts=[len(re.findall(r"[^\s]",f)) for f in frames]
print("chars/frame min/max/avg:",min(counts),max(counts),round(sum(counts)/len(counts),1))
multi=sum(1 for f in frames if f.count("|")>=2)
print("frames with >=2 rockets:",multi)
chars=collections.Counter("".join(frames))
print("char histogram:",dict(sorted(chars.items(),key=lambda kv:-kv[1])))
