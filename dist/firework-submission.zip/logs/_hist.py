﻿import re, collections
raw=open(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\logs\cap_r6.txt",encoding="utf-8",errors="replace").read()
fr=[f for f in raw.split("\x1b[H") if f.strip()]
print("frames",len(fr),"size",len(raw))
c=collections.Counter("".join(fr))
print({k:v for k,v in c.items() if k not in " \n"})
print("first frame chars:",len(re.findall(r"[^\s]",fr[0])))
