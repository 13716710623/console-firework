﻿from pathlib import Path
p=Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c")
s=p.read_text(encoding="utf-8")
reps=[("        dirs = WILLOW_DIRS; layers = 4 + rand() % 5;","        dirs = WILLOW_DIRS; layers = 10 + rand() % 7;"),
      ("        max_speed = PSPEED_MAX * 0.42f; vy_scale = 0.55f;\n        life_min = 120; life_max = 180;","        max_speed = PSPEED_MAX * 0.50f; vy_scale = 0.55f;\n        life_min = 140; life_max = 200;"),
      ("        dim = 2; spark_pct = 0; twinkle_pct = 0;","        dim = 1; spark_pct = 0; twinkle_pct = 0;")]
for o,n in reps:
    assert s.count(o)==1,(o,s.count(o)); s=s.replace(o,n)
p.write_text(s,encoding="utf-8"); print("willow tuned")
