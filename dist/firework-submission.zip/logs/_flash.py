﻿import re, sys
sys.path.insert(0, r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\tools")
from capture_frames import split_frames, PALETTE
from PIL import Image, ImageDraw, ImageFont
raw=open(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\logs\cap_r6.txt",encoding="utf-8",errors="replace").read()
fr=split_frames(raw)
best=max(range(len(fr)), key=lambda i: "".join(fr[i]).count("@"))
print("frames",len(fr),"best frame",best,"@ count","".join(fr[best]).count("@"))
rows=max(len(f) for f in fr); cols=max(max(len(l) for l in f) for f in fr)
font=ImageFont.truetype(r"C:\Windows\Fonts\consola.ttf",16)
cw,ch,m=10,18,8
img=Image.new("RGB",(cols*cw+m*2,rows*ch+m*2),(6,8,18)); dr=ImageDraw.Draw(img)
for r,line in enumerate(fr[best]):
    for c,chx in enumerate(line):
        if chx==" ": continue
        lv="@Oo*,.".find(chx)
        if lv<0: lv=5
        dr.text((m+c*cw,m+r*ch),chx,font=font,fill=PALETTE[lv])
out=r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\shots_r6\flash_frame.png"
img.save(out); print("saved",out)
