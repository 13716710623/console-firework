﻿import re, collections
raw=open(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\logs\cap300.txt",encoding="utf-8",errors="replace").read()
frames=[f for f in raw.split("\x1b[H") if f.strip()]
counts=[len(re.findall(r"[^\s]",f)) for f in frames]
print("frames:",len(frames),"chars/frame min/max/avg:",min(counts),max(counts),round(sum(counts)/len(counts),1))
print("frames with >=2 rockets:",sum(1 for f in frames if f.count("|")>=2),"max rockets:",max(f.count("|") for f in frames))
chars=collections.Counter("".join(frames)); print({k:v for k,v in chars.items() if k not in " \n"})
