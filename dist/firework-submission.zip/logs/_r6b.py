﻿from pathlib import Path
p=Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c")
s=p.read_text(encoding="utf-8")
reps=[
# 拖尾改成两段、更亮
("""        if (q->vx > 0.12f || q->vx < -0.12f || q->vy > 0.12f || q->vy < -0.12f) {
            int tx = px - (int)(q->vx * 1.6f);
            int ty = py - (int)(q->vy * 1.6f);
            int tb = b + 2;
            if (tb > NUM_BRIGHT - 1) tb = NUM_BRIGHT - 1;
            if (tx != px || ty != py) draw_pixel(tx, ty, tb, BRIGHT_CHARS[tb]);
        }""",
 """        if (q->vx > 0.10f || q->vx < -0.10f || q->vy > 0.10f || q->vy < -0.10f) {
            int tb = b + 1 > NUM_BRIGHT - 1 ? NUM_BRIGHT - 1 : b + 1;
            int tx = px - (int)(q->vx * 1.7f);
            int ty = py - (int)(q->vy * 1.7f);
            if (tx != px || ty != py) draw_pixel(tx, ty, tb, BRIGHT_CHARS[tb]);
            tb = b + 3 > NUM_BRIGHT - 1 ? NUM_BRIGHT - 1 : b + 3;
            tx = px - (int)(q->vx * 3.4f);
            ty = py - (int)(q->vy * 3.4f);
            if (tx != px || ty != py) draw_pixel(tx, ty, tb, BRIGHT_CHARS[tb]);
        }"""),
# 火箭烟迹更亮、更长
("""                             ((float)(rand() % 100) - 50.0f) / 400.0f,
                             0.04f + (float)(rand() % 100) / 1500.0f,
                             6 + rand() % 8, KIND_NORMAL, 3);""",
 """                             ((float)(rand() % 100) - 50.0f) / 400.0f,
                             0.04f + (float)(rand() % 100) / 1500.0f,
                             10 + rand() % 10, KIND_NORMAL, 2);"""),
# 爆心闪光更久更亮：粒子数 8 → 14，寿命 8~16
("""    for (k = 0; k < 8; k++) {
        int fd = rand() % UNIT_STEPS;
        float fsp = 0.03f + (float)(rand() % 100) / 2500.0f;
        (void)spawn_particle(cx, cy, cx, cy, UNIT_X[fd] * fsp, UNIT_Y[fd] * fsp,
                             5 + rand() % 5, KIND_NORMAL, 0);
    }""",
 """    for (k = 0; k < 14; k++) {
        int fd = rand() % UNIT_STEPS;
        float fsp = 0.02f + (float)(rand() % 100) / 3000.0f;
        (void)spawn_particle(cx, cy, cx, cy, UNIT_X[fd] * fsp, UNIT_Y[fd] * fsp,
                             8 + rand() % 9, KIND_NORMAL, 0);
    }"""),
]
for o,n in reps:
    assert s.count(o)==1,(o[:40],s.count(o)); s=s.replace(o,n)
p.write_text(s,encoding="utf-8"); print("R6b applied")
