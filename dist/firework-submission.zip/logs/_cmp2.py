﻿import re
for name in ('cap_r5','cap_r6'):
    raw=open(rf"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\logs\{name}.txt",encoding="utf-8",errors="replace").read()
    fr=[f for f in raw.split("\x1b[H") if f.strip()]
    c=[len(re.findall(r"[^\s]",f)) for f in fr]
    print(name,len(fr),"avg",round(sum(c)/len(c),1),"max",max(c))
