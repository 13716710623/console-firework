﻿from pathlib import Path

PALETTE = """PALETTE = [
    (255, 255, 236),   # @
    (255, 232, 170),   # O
    (255, 205, 125),   # o
    (245, 170, 95),    # *
    (215, 130, 80),    # ,
    (180, 105, 80),    # .
]
"""

files = [
    r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\tools\capture_frames.py",
    r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\tools\frames_to_video.py",
    r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\tools\montage.py",
]
replacements = [
    ("""                level = "@Oo*,.".find(ch_)
                brightness = 255 if level <= 0 else max(70, 235 - level * 28)
                color = (brightness, max(60, brightness - 40), max(40, brightness - 90))
                d.text((margin + c * cw, margin + r * ch), ch_, font=font, fill=color)""",
     """                level = "@Oo*,.".find(ch_)
                if level < 0:
                    level = 5
                d.text((margin + c * cw, margin + r * ch), ch_, font=font,
                       fill=PALETTE[level])"""),
    ("""                level = "@Oo*,.".find(ch_)
                b = 255 if level <= 0 else max(70, 235 - level * 28)
                d.text((margin + c * cw, margin + r * ch), ch_, font=font,
                       fill=(b, max(60, b - 40), max(40, b - 90)))""",
     """                level = "@Oo*,.".find(ch_)
                if level < 0:
                    level = 5
                d.text((margin + c * cw, margin + r * ch), ch_, font=font,
                       fill=PALETTE[level])"""),
    ("""                level = "@Oo*,.".find(ch_)
                b = 255 if level <= 0 else max(70, 235 - level * 28)
                d.text((ox + pad + c * cw, oy + 20 + r * ch), ch_, font=font,
                       fill=(b, max(60, b - 40), max(40, b - 90)))""",
     """                level = "@Oo*,.".find(ch_)
                if level < 0:
                    level = 5
                d.text((ox + pad + c * cw, oy + 20 + r * ch), ch_, font=font,
                       fill=PALETTE[level])"""),
]
for f in files:
    s = Path(f).read_text(encoding="utf-8")
    for old, new in replacements:
        if old in s:
            s = s.replace(old, new)
            break
    if "PALETTE = [" not in s:
        s = s.replace("from PIL import Image, ImageDraw, ImageFont", "from PIL import Image, ImageDraw, ImageFont\n\n" + PALETTE)
    Path(f).write_text(s, encoding="utf-8")
    print("patched", Path(f).name, "palette" if "PALETTE[level]" in s else "MISS")
