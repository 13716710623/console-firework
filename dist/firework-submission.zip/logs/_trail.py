﻿from pathlib import Path
p=Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c")
s=p.read_text(encoding="utf-8")
old="""        if (q->vx > 0.10f || q->vx < -0.10f || q->vy > 0.10f || q->vy < -0.10f) {
            int tb = b + 1 > NUM_BRIGHT - 1 ? NUM_BRIGHT - 1 : b + 1;
            int tx = px - (int)(q->vx * 1.7f);
            int ty = py - (int)(q->vy * 1.7f);
            if (tx != px || ty != py) draw_pixel(tx, ty, tb, BRIGHT_CHARS[tb]);
            tb = b + 3 > NUM_BRIGHT - 1 ? NUM_BRIGHT - 1 : b + 3;
            tx = px - (int)(q->vx * 3.4f);
            ty = py - (int)(q->vy * 3.4f);
            if (tx != px || ty != py) draw_pixel(tx, ty, tb, BRIGHT_CHARS[tb]);
        }"""
new="""        if (q->vx > 0.12f || q->vx < -0.12f || q->vy > 0.12f || q->vy < -0.12f) {
            /* 拖尾：按速度方向的 8 邻域取整，保证任何速度下都有 1~2 格可见尾巴 */
            int sx = (q->vx > 0.12f) - (q->vx < -0.12f);
            int sy = (q->vy > 0.12f) - (q->vy < -0.12f);
            int tb = b + 1 > NUM_BRIGHT - 1 ? NUM_BRIGHT - 1 : b + 1;
            draw_pixel(px - sx, py - sy, tb, BRIGHT_CHARS[tb]);
            tb = b + 3 > NUM_BRIGHT - 1 ? NUM_BRIGHT - 1 : b + 3;
            draw_pixel(px - 2 * sx, py - 2 * sy, tb, BRIGHT_CHARS[tb]);
        }"""
assert s.count(old)==1
s=s.replace(old,new)
p.write_text(s,encoding="utf-8"); print("trail fixed")
