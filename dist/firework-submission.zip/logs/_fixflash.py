﻿from pathlib import Path
p=Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\logs\_flash.py")
s=p.read_text(encoding="utf-8").replace('fr[i].count("@")','"".join(fr[i]).count("@")').replace('fr[best].count("@")','"".join(fr[best]).count("@")')
p.write_text(s,encoding="utf-8"); print("fixed")
