﻿from pathlib import Path
s=Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\firework.c").read_text(encoding="utf-8")
s=s.replace("        explode(choose_explosion_type(), r->x, r->y);","        { int t_ = choose_explosion_type(); fprintf(stderr, \"EXTYPE %d\\n\", t_); explode(t_, r->x, r->y); }",1)
Path(r"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\_dbgtype.c").write_text(s,encoding="utf-8")
print("ok")
