﻿import re
for name in ('cap_r5','cap_r6'):
    raw=open(rf"C:\Users\14495\Documents\deepseek-harness\default-workspace\contest-firework\logs\{name}.txt",encoding="utf-8",errors="replace").read()
    fr=[f for f in raw.split("\x1b[H") if f.strip()]
    counts=[len(re.findall(r"[^\s]",f)) for f in fr]
    print(name, "frames",len(fr),"avg chars",round(sum(counts)/len(counts),1),"max",max(counts))
